---
title: 공통 API 응답 설계 문서
slug: 공통-인프라-공통-api-응답-설계
type: deliverable
sdlc_phase: design
domain: 공통/인프라
subdomain: 공통 API 응답
status: active
source_count: 1
sources:
- /home/lstguardleft/workspace/Project-Wiki-Manager/raw/20260528-144314-공통API응답.md.md
updated: '2026-05-28'
---

# 공통 API 응답 설계

**문서 버전:** v1.0  
**도메인 / 서브도메인:** 공통/인프라 / 공통 API 응답  
**SDLC 단계:** 설계  

## 1. 설계 개요

`ApiResponse<T>` 제네릭 DTO를 정의하고, 모든 Controller가 이를 반환하도록 표준화한다.

## 2. 구성 요소

| 계층 | 구성 요소 | 역할 |
|---|---|---|
| DTO | ApiResponse<T> | 공통 응답 |
| Util | ApiResponse.success(data) / ApiResponse.fail() | 정적 팩토리 |

## 3. 데이터 / 항목

| 필드 | 형식 |
|---|---|
| success | boolean |
| data | T |

## 4. 인터페이스

별도 엔드포인트 없음. 모든 Controller가 `ApiResponse<T>`를 반환.

## 5. 설계 규칙

- 응답 본문은 항상 `ApiResponse<T>` 직렬화 형태.
- HTTP 상태코드는 별도로 설정 (`@ResponseStatus` 또는 `ResponseEntity`).

## 6. 의존 서브도메인

| 연관 기능 | 의존 내용 |
|---|---|
| [[전역예외처리]] | 실패 응답 생성 |

---

## 7. 연관 도메인 / 서브도메인 / 관계

_이 표는 상호참조 Agent가 자동으로 유지합니다 — 직접 편집한 내용은 다음 적재 시 덮어쓰여집니다._

| 도메인 | 서브도메인 (페이지) | 관계 | 핵심 사유 | 함께 볼 때 |
|---|---|---|---|---|
| 공통/인프라 | 공통 API 응답 [[공통-인프라-공통-api-응답-구현]] | 구현 | 공통 API 응답 설계를 구현하는 문서. | 공통 API 응답의 설계와 구현을 함께 검토하여 일관성을 확인해야 한다. |
| 공통/인프라 | 공통 API 응답 [[공통-인프라-공통-api-응답-요구사항]] | 구현 | 공통 API 응답 요구사항을 구현하는 문서. | 공통 API 응답의 설계와 요구사항을 함께 검토하여 일관성을 확인해야 한다. |
