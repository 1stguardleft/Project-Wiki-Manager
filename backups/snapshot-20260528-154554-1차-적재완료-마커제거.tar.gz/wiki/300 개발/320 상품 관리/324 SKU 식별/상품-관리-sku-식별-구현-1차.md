---
title: 상품 관리 SKU 식별 구현 문서
slug: 상품-관리-sku-식별-구현-1차
type: deliverable
sdlc_phase: implementation
domain: 상품 관리
subdomain: SKU 식별
status: active
source_count: 1
sources:
- /home/lstguardleft/workspace/Project-Wiki-Manager/raw/20260528-150400-SKU식별.md.md
updated: '2026-05-28'
---

# 상품 관리 - SKU 식별 - 구현

**문서 버전:** v1.0  
**도메인 / 서브도메인:** 상품 관리 / SKU 식별  
**SDLC 단계:** 구현  

## 1. 구현 범위

Product 엔티티에 `sku` 컬럼만 추가 (NOT NULL). 별도 검증·인덱스 없음.

## 2. 구현 항목 체크리스트

- [ ] Product 엔티티 `sku` 필드 정의
- [ ] DTO에 sku 포함
- [ ] DDL에 `sku NOT NULL` 추가

## 3. 적용 기술

- JPA `@Column(nullable = false)`

## 4. 단계별 작업 순서

1. 엔티티 필드 추가  
2. DTO 동기화  
3. 등록·수정 검증 확인  

## 5. 위험 요소

| 위험 | 대응 |
|---|---|
| SKU 중복으로 운영 혼란 | 1차에는 허용, 2차에서 unique 적용 |

## 6. 검증 포인트

- sku 누락 시 400 오류 발생

## 7. 연관 작업

| 연관 | 관계 |
|---|---|
| [[상품기본정보]] | sku 컬럼 공유 |

---

## 8. 연관 도메인 / 서브도메인 / 관계

_이 표는 상호참조 Agent가 자동으로 유지합니다 — 직접 편집한 내용은 다음 적재 시 덮어쓰여집니다._

| 도메인 | 서브도메인 (페이지) | 관계 | 핵심 사유 | 함께 볼 때 |
|---|---|---|---|---|
| 상품 관리 | SKU 식별 [[상품-관리-sku-식별-설계-1차]] | 구현 | 설계 문서의 내용을 구현한 사례. | SKU 필드의 구현을 이해하기 위해 설계 문서와 함께 봐야 한다. |
| 상품 관리 | SKU 식별 [[상품-관리-sku-식별-요구사항-1차]] | 구현 | 요구사항 문서의 내용을 구현한 사례. | SKU 필드의 구현을 이해하기 위해 요구사항 문서와 함께 봐야 한다. |
