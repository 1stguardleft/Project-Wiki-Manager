---
title: 공통 API 응답 구현 가이드
slug: 공통-인프라-공통-api-응답-구현
type: deliverable
sdlc_phase: implementation
domain: 공통/인프라
subdomain: 공통 API 응답
status: active
source_count: 1
sources:
- /home/lstguardleft/workspace/Project-Wiki-Manager/raw/20260528-150001-공통API응답.md.md
updated: '2026-05-28'
---

# 공통 API 응답 구현

**문서 버전:** v1.0  
**도메인 / 서브도메인:** 공통/인프라 / 공통 API 응답  
**SDLC 단계:** 구현  

## 1. 구현 범위

ApiResponse<T> 제네릭 DTO와 정적 팩토리 메서드 작성.

## 2. 구현 항목 체크리스트

- [ ] `class ApiResponse<T> { boolean success; T data; }`
- [ ] `static <T> ApiResponse<T> success(T data)`
- [ ] `static ApiResponse<Void> fail()`
- [ ] 모든 Controller에 적용 (점진 마이그레이션)
- [ ] 직렬화 테스트

## 3. 적용 기술

- Jackson 직렬화
- Spring Web

## 4. 단계별 작업 순서

1. DTO 정의
2. 한 도메인 적용해 검증
3. 전 도메인 적용

## 5. 위험 요소

| 위험 | 대응 |
|---|---|
| 일부 도메인이 표준을 따르지 않음 | PR 리뷰로 강제 |

## 6. 검증 포인트

- success/data 직렬화 정확
- null 데이터 시 data:null

## 7. 연관 작업

| 연관 | 관계 |
|---|---|
| [[전역예외처리]] | 실패 응답 생성 |

---

## 8. 연관 도메인 / 서브도메인 / 관계

_이 표는 상호참조 Agent가 자동으로 유지합니다 — 직접 편집한 내용은 다음 적재 시 덮어쓰여집니다._

| 도메인 | 서브도메인 (페이지) | 관계 | 핵심 사유 | 함께 볼 때 |
|---|---|---|---|---|
| 공통/인프라 | 공통 API 응답 [[공통-인프라-공통-api-응답-설계]] | 구현 | API 응답 설계가 구현에 반영된다. | 설계 문서를 통해 API 응답의 구조를 이해한 후, 구현 문서를 참고하여 실제 코드를 작성해야 한다. |
| 공통/인프라 | 공통 API 응답 [[공통-인프라-공통-api-응답-요구사항]] | 구현 | 요구사항이 구현에 직접적으로 반영된다. | 요구사항 문서를 통해 API 응답의 필수 요소를 이해한 후, 구현 문서를 참고하여 코드를 작성해야 한다. |
| 공통/인프라 | 전역 예외 처리 [[공통-인프라-전역-예외-처리-구현]] | 구현 | 전역 예외 처리 구현이 실패 응답 생성과 연결된다. | 전역 예외 처리 문서를 통해 실패 응답 생성 방식을 이해하고, 구현 문서에서 이를 적용해야 한다. |
